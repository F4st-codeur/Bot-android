package com.colin.blitzbot;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Écran de réglages. Le bot lui-même tourne dans BotService (panneau flottant). */
public class MainActivity extends Activity {

    private Prefs prefs;
    private EditText delay, drag, minV, trayScale;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("BlitzBot");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("1. Active le service « BlitzBot » dans Accessibilité.\n"
                + "   (Android 13+ : si c'est grisé → Infos de l'appli → ⋮ → Autoriser les paramètres restreints)\n"
                + "2. Ouvre Block Blitz et lance une partie Classic.\n"
                + "3. Dans le panneau flottant : « Cadrer » → encadre la grille 8x8, puis la zone des 3 pièces.\n"
                + "4. Appuie sur ▶ Jouer. Les premiers coups servent au calage (pièce posée au centre).\n\n"
                + "Mode Debug : points verts = cases vues pleines, cadres jaunes = pièces détectées, "
                + "violet = coup prévu.");
        help.setPadding(0, pad, 0, pad);
        root.addView(help);

        Button acc = new Button(this);
        acc.setText("Ouvrir les réglages d'accessibilité");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        delay = field(root, "Pause après chaque coup (ms)", String.valueOf(prefs.delayMs()), false);
        drag = field(root, "Durée du glissé (ms)", String.valueOf(prefs.dragMs()), false);
        minV = field(root, "Seuil de luminosité des blocs (0.2–0.8)", String.valueOf(prefs.minV()), true);
        trayScale = field(root, "Taille des pièces en attente / case de grille (0 = auto)",
                String.valueOf(prefs.trayScale()), true);

        Button save = new Button(this);
        save.setText("Enregistrer");
        save.setOnClickListener(v -> save());
        root.addView(save);

        Button reset = new Button(this);
        reset.setText("Refaire le calage automatique");
        reset.setOnClickListener(v -> {
            prefs.resetLearning();
            Toast.makeText(this, "Calage réinitialisé", Toast.LENGTH_SHORT).show();
        });
        root.addView(reset);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private EditText field(LinearLayout root, String label, String value, boolean decimal) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setPadding(0, 24, 0, 0);
        root.addView(t);
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(decimal ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_NUMBER);
        root.addView(e);
        return e;
    }

    private void save() {
        try {
            prefs.setDelayMs(Integer.parseInt(delay.getText().toString().trim()));
            prefs.setDragMs(Integer.parseInt(drag.getText().toString().trim()));
            prefs.setMinV(Float.parseFloat(minV.getText().toString().trim()));
            prefs.setTrayScale(Float.parseFloat(trayScale.getText().toString().trim()));
            Toast.makeText(this, "Enregistré", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException ex) {
            Toast.makeText(this, "Valeur invalide", Toast.LENGTH_SHORT).show();
        }
    }
}
