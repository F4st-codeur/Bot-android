package com.colin.blitzbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Service d'accessibilité : capture l'écran, lit la grille, calcule le meilleur coup
 * et fait glisser les pièces avec de faux gestes tactiles.
 */
public class BotService extends AccessibilityService {

    private WindowManager wm;
    private Handler main;
    private HandlerThread thread;
    private Handler bot;
    private Prefs prefs;

    private LinearLayout panel;
    private Button playBtn;
    private TextView status;
    private DebugView debugView;
    private CalibrationView calibView;
    private boolean debugOn = true;

    private volatile boolean running;

    // ------------------------------------------------------------ Lifecycle

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        main = new Handler(Looper.getMainLooper());
        prefs = new Prefs(this);
        thread = new HandlerThread("blitzbot");
        thread.start();
        bot = new Handler(thread.getLooper());
        createDebugView();
        createPanel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { running = false; }

    @Override
    public void onDestroy() {
        running = false;
        removeView(panel);
        removeView(debugView);
        removeView(calibView);
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    private void removeView(View v) {
        if (v != null && v.isAttachedToWindow()) wm.removeView(v);
    }

    // ------------------------------------------------------------------- UI

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private WindowManager.LayoutParams fullScreenParams(boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        lp.setFitInsetsTypes(0);
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        return lp;
    }

    private void createDebugView() {
        debugView = new DebugView(this);
        wm.addView(debugView, fullScreenParams(false));
    }

    private Button smallButton(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void createPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(200, 20, 20, 20));
        panel.setPadding(dp(4), dp(4), dp(4), dp(4));

        LinearLayout row = new LinearLayout(this);
        playBtn = smallButton("▶ Jouer", v -> toggle());
        row.addView(playBtn);
        row.addView(smallButton("Cadrer", v -> startCalibration()));
        row.addView(smallButton("Debug", v -> {
            debugOn = !debugOn;
            debugView.setVisibility(debugOn ? View.VISIBLE : View.GONE);
        }));
        panel.addView(row);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(11);
        status.setMaxWidth(dp(230));
        status.setText(prefs.board() == null ? "Commence par « Cadrer »" : "Prêt");
        panel.addView(status);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = dp(30);
        wm.addView(panel, lp);
    }

    private void setStatus(String s) {
        main.post(() -> status.setText(s));
    }

    private void startCalibration() {
        if (running) toggle();
        if (calibView != null) return;
        panel.setVisibility(View.GONE);
        calibView = new CalibrationView(this, new CalibrationView.Listener() {
            @Override
            public void onDone(Rect board, Rect tray) {
                prefs.setBoard(board);
                prefs.setTray(tray);
                prefs.resetLearning();
                closeCalibration();
                setStatus("Cadrage enregistré. Lance une partie puis ▶");
            }

            @Override
            public void onCancel() { closeCalibration(); }
        });
        wm.addView(calibView, fullScreenParams(true));
    }

    private void closeCalibration() {
        removeView(calibView);
        calibView = null;
        panel.setVisibility(View.VISIBLE);
    }

    private void toggle() {
        if (running) {
            running = false;
            playBtn.setText("▶ Jouer");
            setStatus("Arrêté");
        } else {
            if (prefs.board() == null || prefs.tray() == null) {
                setStatus("Fais d'abord « Cadrer »");
                return;
            }
            running = true;
            playBtn.setText("■ Stop");
            bot.post(this::loop);
        }
    }

    private void stopFromBot(String msg) {
        running = false;
        main.post(() -> {
            playBtn.setText("▶ Jouer");
            status.setText(msg);
        });
    }

    // ------------------------------------------------------------- Capture

    private void runOnMainAndWait(Runnable r) {
        CountDownLatch l = new CountDownLatch(1);
        main.post(() -> {
            r.run();
            l.countDown();
        });
        try { l.await(1, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
    }

    private Bitmap capture() {
        runOnMainAndWait(() -> debugView.setVisibility(View.INVISIBLE));
        sleep(70);
        final Bitmap[] out = new Bitmap[1];
        CountDownLatch l = new CountDownLatch(1);
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult result) {
                HardwareBuffer hb = result.getHardwareBuffer();
                Bitmap hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                if (hw != null) {
                    out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                    hw.recycle();
                }
                hb.close();
                l.countDown();
            }

            @Override
            public void onFailure(int errorCode) { l.countDown(); }
        });
        try { l.await(3, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        if (debugOn) main.post(() -> debugView.setVisibility(View.VISIBLE));
        return out[0];
    }

    // ------------------------------------------------------------- Gestes

    /** Appui, petite pause, glissé, petite pause, relâché. */
    private boolean drag(float x1, float y1, float x2, float y2, long dur) {
        android.graphics.Point size = new android.graphics.Point();
        getSystemService(android.hardware.display.DisplayManager.class)
                .getDisplay(Display.DEFAULT_DISPLAY).getRealSize(size);
        Rect screen = new Rect(0, 0, size.x, size.y);
        x1 = clampF(x1, 1, screen.width() - 2);
        x2 = clampF(x2, 1, screen.width() - 2);
        y1 = clampF(y1, 1, screen.height() - 2);
        y2 = clampF(y2, 1, screen.height() - 2);

        Path p1 = new Path();
        p1.moveTo(x1, y1);
        p1.lineTo(x1 + 1, y1 + 1);
        GestureDescription.StrokeDescription s1 = new GestureDescription.StrokeDescription(p1, 0, 90, true);

        Path p2 = new Path();
        p2.moveTo(x1 + 1, y1 + 1);
        p2.lineTo(x2, y2);
        GestureDescription.StrokeDescription s2 = s1.continueStroke(p2, 0, dur, true);

        Path p3 = new Path();
        p3.moveTo(x2, y2);
        p3.lineTo(x2 + 1, y2);
        GestureDescription.StrokeDescription s3 = s2.continueStroke(p3, 0, 80, false);

        return dispatch(s1) && dispatch(s2) && dispatch(s3);
    }

    private boolean dispatch(GestureDescription.StrokeDescription s) {
        AtomicBoolean ok = new AtomicBoolean(false);
        CountDownLatch l = new CountDownLatch(1);
        GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
        main.post(() -> {
            boolean sent = dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription d) {
                    ok.set(true);
                    l.countDown();
                }

                @Override
                public void onCancelled(GestureDescription d) { l.countDown(); }
            }, main);
            if (!sent) l.countDown();
        });
        try { l.await(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        return ok.get();
    }

    private static float clampF(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    // ---------------------------------------------------------------- Bot

    /** Coup joué au tour précédent, pour vérifier où la pièce est réellement tombée. */
    private static final class Pending {
        long before;
        Solver.Piece piece;
        Solver.Move move;
        boolean clears;
        boolean calibrationMove;
    }

    private void loop() {
        Pending pending = null;
        int fails = 0, waits = 0, moves = 0;

        while (running) {
            Rect board = prefs.board(), tray = prefs.tray();
            float cell = board.width() / 8f;
            float minV = prefs.minV();

            Bitmap bmp = capture();
            if (bmp == null) {
                setStatus("Capture impossible, nouvel essai…");
                sleep(500);
                continue;
            }
            long cells = ScreenReader.readBoard(bmp, board, minV);
            List<ScreenReader.TrayPiece> tps = ScreenReader.findTrayBoxes(bmp, tray, minV);

            // Taille des cases dans la zone d'attente
            float unit;
            if (prefs.trayScale() > 0) {
                unit = cell * prefs.trayScale();
            } else {
                float est = ScreenReader.estimateUnit(tps, cell);
                float learned = prefs.learnedUnit();
                if (est > 0 && (learned <= 0 || est / cell < learned - 0.01f)) {
                    learned = est / cell;
                    prefs.setLearnedUnit(learned);
                }
                unit = learned > 0 ? learned * cell : cell * 0.5f;
            }
            ScreenReader.readShapes(bmp, tps, unit, minV);
            bmp.recycle();

            // --- Vérification du coup précédent (apprentissage du décalage)
            if (pending != null) {
                if (cells == pending.before) {
                    fails++;
                    if (fails >= 3) {
                        stopFromBot("La pièce n'est pas posée. Vérifie le cadrage / le mode Debug.");
                        break;
                    }
                } else {
                    fails = 0;
                    if (!prefs.calibrated() && !pending.clears) learn(pending, cells, cell);
                }
                pending = null;
            }

            List<Solver.Piece> pieces = new ArrayList<>();
            List<ScreenReader.TrayPiece> valid = new ArrayList<>();
            for (ScreenReader.TrayPiece tp : tps)
                if (tp.piece != null) {
                    pieces.add(tp.piece);
                    valid.add(tp);
                }

            if (pieces.isEmpty()) {
                updateDebug(board, tray, cells, tps, 0);
                if (++waits > 25) {
                    stopFromBot("Aucune pièce détectée (partie finie ?)");
                    break;
                }
                setStatus("En attente des pièces…");
                sleep(400);
                continue;
            }
            waits = 0;

            boolean calib = !prefs.calibrated();
            Solver.Move m;
            if (calib) {
                m = Solver.centerMove(cells, pieces);
                if (m == null) m = firstOf(Solver.solve(cells, pieces));
            } else {
                m = firstOf(Solver.solve(cells, pieces));
            }
            if (m == null) {
                updateDebug(board, tray, cells, tps, 0);
                stopFromBot("Plus aucun coup possible. Coups joués : " + moves);
                break;
            }

            Solver.Piece p = pieces.get(m.piece);
            ScreenReader.TrayPiece tp = valid.get(m.piece);
            long mask = p.maskAt(m.row, m.col);
            int[] out = new int[1];
            Solver.clear(cells | mask, out);
            updateDebug(board, tray, cells, tps, mask);

            float tx = board.left + (m.col + p.cols / 2f) * cell + prefs.dx();
            float ty = board.top + (m.row + p.rows / 2f) * (board.height() / 8f) + prefs.dy();
            setStatus((calib ? "[calage] " : "") + "Coup " + (moves + 1) + " : " + p.rows + "x" + p.cols
                    + " → ligne " + (m.row + 1) + ", col " + (m.col + 1));

            if (!drag(tp.box.centerX(), tp.box.centerY(), tx, ty, prefs.dragMs())) {
                setStatus("Geste refusé par le système");
            }
            moves++;

            pending = new Pending();
            pending.before = cells;
            pending.piece = p;
            pending.move = m;
            pending.clears = out[0] > 0;
            pending.calibrationMove = calib;

            sleep(prefs.delayMs());
        }
    }

    private static Solver.Move firstOf(Solver.Plan plan) {
        return plan == null || plan.moves.isEmpty() ? null : plan.moves.get(0);
    }

    /** Compare l'endroit visé et l'endroit réel pour corriger le décalage doigt/pièce. */
    private void learn(Pending pd, long after, float cell) {
        long added = after & ~pd.before;
        if (Long.bitCount(added) != pd.piece.count) return;
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++)
                if (pd.piece.maskAt(r, c) == added) {
                    int dR = r - pd.move.row, dC = c - pd.move.col;
                    float rowH = prefs.board().height() / 8f;
                    if (dR == 0 && dC == 0) {
                        prefs.setOffset(prefs.dx(), prefs.dy(), true);
                        setStatus("Calage OK ✔");
                    } else {
                        prefs.setOffset(prefs.dx() - dC * cell, prefs.dy() - dR * rowH, false);
                        setStatus("Correction du décalage (" + dR + "," + dC + ")…");
                    }
                    return;
                }
    }

    private void updateDebug(Rect board, Rect tray, long cells, List<ScreenReader.TrayPiece> tps, long plan) {
        main.post(() -> debugView.update(board, tray, cells, tps, plan));
    }
}
