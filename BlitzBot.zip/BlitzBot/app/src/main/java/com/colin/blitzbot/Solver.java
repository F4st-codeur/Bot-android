package com.colin.blitzbot;

import java.util.ArrayList;
import java.util.List;

/**
 * Solveur pour une grille 8x8 type "Block Blast".
 * La grille est un long : bit (r*8 + c) = 1 si la case est occupée.
 * Pure Java : aucune dépendance Android (testable sur PC).
 */
public final class Solver {

    public static final int N = 8;
    static final long[] ROW = new long[N];
    static final long[] COL = new long[N];
    static final long NOT_COL0, NOT_COL7, NOT_ROW7;
    static final long[] SQ3, H5, V5, H3, V3;

    static {
        for (int r = 0; r < N; r++)
            for (int c = 0; c < N; c++) {
                ROW[r] |= bit(r, c);
                COL[c] |= bit(r, c);
            }
        NOT_COL0 = ~COL[0];
        NOT_COL7 = ~COL[7];
        NOT_ROW7 = ~ROW[7];
        SQ3 = rects(3, 3);
        H5 = rects(1, 5);
        V5 = rects(5, 1);
        H3 = rects(1, 3);
        V3 = rects(3, 1);
    }

    static long bit(int r, int c) {
        return 1L << (r * 8 + c);
    }

    static long[] rects(int h, int w) {
        List<Long> l = new ArrayList<>();
        for (int r = 0; r + h <= N; r++)
            for (int c = 0; c + w <= N; c++) {
                long m = 0;
                for (int i = 0; i < h; i++)
                    for (int j = 0; j < w; j++) m |= bit(r + i, c + j);
                l.add(m);
            }
        long[] a = new long[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    // ------------------------------------------------------------------ Piece

    public static final class Piece {
        public final int rows, cols, count;
        public final boolean[][] cells;
        final long base;

        public Piece(boolean[][] cells) {
            this.cells = cells;
            this.rows = cells.length;
            this.cols = cells[0].length;
            long b = 0;
            int n = 0;
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    if (cells[r][c]) {
                        b |= bit(r, c);
                        n++;
                    }
            this.base = b;
            this.count = n;
        }

        /** Masque de la pièce posée avec son coin haut-gauche en (r,c), ou 0 si hors grille. */
        public long maskAt(int r, int c) {
            if (r < 0 || c < 0 || r + rows > N || c + cols > N) return 0;
            return base << (r * 8 + c);
        }

        boolean sameShape(Piece o) {
            return o.base == base && o.rows == rows && o.cols == cols;
        }

        public static Piece parse(String... lines) {
            boolean[][] g = new boolean[lines.length][lines[0].length()];
            for (int r = 0; r < lines.length; r++)
                for (int c = 0; c < lines[r].length(); c++) g[r][c] = lines[r].charAt(c) == '#';
            return new Piece(g);
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (boolean[] row : cells) {
                for (boolean b : row) sb.append(b ? '#' : '.');
                sb.append('/');
            }
            return sb.toString();
        }
    }

    public static final class Move {
        public final int piece, row, col;

        Move(int piece, int row, int col) {
            this.piece = piece;
            this.row = row;
            this.col = col;
        }

        @Override
        public String toString() {
            return "pièce " + piece + " -> (" + row + "," + col + ")";
        }
    }

    public static final class Plan {
        public final List<Move> moves = new ArrayList<>();
        public double score = Double.NEGATIVE_INFINITY;
        public int lines;
    }

    // ------------------------------------------------------------- Mécanique

    /** Efface les lignes/colonnes pleines. out[0] = nombre de lignes effacées. */
    public static long clear(long board, int[] out) {
        long full = 0;
        int n = 0;
        for (int i = 0; i < N; i++) {
            if ((board & ROW[i]) == ROW[i]) {
                full |= ROW[i];
                n++;
            }
            if ((board & COL[i]) == COL[i]) {
                full |= COL[i];
                n++;
            }
        }
        if (out != null) out[0] = n;
        return board & ~full;
    }

    /** Note heuristique d'une grille (plus haut = mieux). */
    public static double evaluate(long board) {
        long empty = ~board;
        int filled = Long.bitCount(board);

        // Cases vides isolées (aucun voisin vide) = trous difficiles à remplir.
        long nb = ((empty << 1) & NOT_COL0) | ((empty >>> 1) & NOT_COL7) | (empty << 8) | (empty >>> 8);
        int holes = Long.bitCount(empty & ~nb);

        // Transitions plein/vide (les bords comptent comme pleins) = fragmentation.
        int hT = Long.bitCount((board ^ (board >>> 1)) & NOT_COL7)
                + Long.bitCount(empty & COL[0]) + Long.bitCount(empty & COL[7]);
        int vT = Long.bitCount((board ^ (board >>> 8)) & NOT_ROW7)
                + Long.bitCount(empty & ROW[0]) + Long.bitCount(empty & ROW[7]);

        double s = -2.0 * filled - 22.0 * holes - 2.5 * (hT + vT);
        s += fits(board, SQ3) ? 35 : -70;
        s += fits(board, H5) ? 15 : -35;
        s += fits(board, V5) ? 15 : -35;
        s += fits(board, H3) ? 0 : -25;
        s += fits(board, V3) ? 0 : -25;
        return s;
    }

    static boolean fits(long board, long[] masks) {
        for (long m : masks) if ((board & m) == 0) return true;
        return false;
    }

    static double lineReward(int n) {
        return n == 0 ? 0 : 120.0 * n + 60.0 * n * (n - 1);
    }

    // --------------------------------------------------------------- Search

    private static final class Ctx {
        List<Piece> pieces;
        Plan best = new Plan();
        Move[] stack;
        int bestPlaced = -1;
    }

    /** Cherche le meilleur enchaînement (toutes les permutations, toutes les positions). */
    public static Plan solve(long board, List<Piece> pieces) {
        Ctx ctx = new Ctx();
        ctx.pieces = pieces;
        ctx.stack = new Move[pieces.size()];
        dfs(ctx, board, 0, 0, 0, 0.0, 0);
        return ctx.best.moves.isEmpty() ? null : ctx.best;
    }

    private static void dfs(Ctx ctx, long board, int used, int depth, int lines, double reward, int dummy) {
        boolean any = false;
        List<Piece> ps = ctx.pieces;
        int[] out = new int[1];
        for (int i = 0; i < ps.size(); i++) {
            if ((used & (1 << i)) != 0) continue;
            Piece p = ps.get(i);
            // évite d'explorer deux fois la même forme au même niveau
            boolean dup = false;
            for (int j = 0; j < i; j++)
                if ((used & (1 << j)) == 0 && ps.get(j).sameShape(p)) {
                    dup = true;
                    break;
                }
            if (dup) continue;
            for (int r = 0; r + p.rows <= N; r++)
                for (int c = 0; c + p.cols <= N; c++) {
                    long m = p.maskAt(r, c);
                    if ((board & m) != 0) continue;
                    any = true;
                    long nb = clear(board | m, out);
                    ctx.stack[depth] = new Move(i, r, c);
                    dfs(ctx, nb, used | (1 << i), depth + 1, lines + out[0], reward + lineReward(out[0]), 0);
                }
        }
        if (!any && depth > 0) {
            double score = depth * 1_000_000.0 + reward + evaluate(board);
            if (score > ctx.best.score) {
                ctx.best.score = score;
                ctx.best.lines = lines;
                ctx.best.moves.clear();
                for (int k = 0; k < depth; k++) ctx.best.moves.add(ctx.stack[k]);
            }
        }
    }

    /** Coup de calibration : pose une pièce au plus près du centre (tolère une erreur de décalage). */
    public static Move centerMove(long board, List<Piece> pieces) {
        Move best = null;
        double bestD = Double.MAX_VALUE;
        for (int i = 0; i < pieces.size(); i++) {
            Piece p = pieces.get(i);
            for (int r = 0; r + p.rows <= N; r++)
                for (int c = 0; c + p.cols <= N; c++) {
                    long m = p.maskAt(r, c);
                    if ((board & m) != 0) continue;
                    int[] out = new int[1];
                    clear(board | m, out);
                    if (out[0] > 0) continue; // pas d'effacement : sinon on ne peut pas mesurer
                    double cr = r + p.rows / 2.0 - 4, cc = c + p.cols / 2.0 - 4;
                    double d = cr * cr + cc * cc - p.count * 0.01;
                    if (d < bestD) {
                        bestD = d;
                        best = new Move(i, r, c);
                    }
                }
        }
        return best;
    }

    public static String toString(long board) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) sb.append((board & bit(r, c)) != 0 ? '#' : '.');
            sb.append('\n');
        }
        return sb.toString();
    }
}
