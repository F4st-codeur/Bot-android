package com.colin.blitzbot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;

/** Réglages persistants. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getSharedPreferences("blitzbot", Context.MODE_PRIVATE);
    }

    public Rect board() { return rect("board"); }
    public Rect tray() { return rect("tray"); }
    public void setBoard(Rect r) { putRect("board", r); }
    public void setTray(Rect r) { putRect("tray", r); }

    private Rect rect(String k) {
        if (!sp.contains(k + "_l")) return null;
        return new Rect(sp.getInt(k + "_l", 0), sp.getInt(k + "_t", 0),
                sp.getInt(k + "_r", 0), sp.getInt(k + "_b", 0));
    }

    private void putRect(String k, Rect r) {
        sp.edit().putInt(k + "_l", r.left).putInt(k + "_t", r.top)
                .putInt(k + "_r", r.right).putInt(k + "_b", r.bottom).apply();
    }

    /** Décalage doigt -> centre de la pièce, appris automatiquement (pixels). */
    public float dx() { return sp.getFloat("dx", 0f); }
    public float dy() { return sp.getFloat("dy", 0f); }
    public boolean calibrated() { return sp.getBoolean("calibrated", false); }

    public void setOffset(float dx, float dy, boolean calibrated) {
        sp.edit().putFloat("dx", dx).putFloat("dy", dy).putBoolean("calibrated", calibrated).apply();
    }

    /** Taille de case dans la zone d'attente, en fraction de la case de la grille (0 = auto). */
    public float trayScale() { return sp.getFloat("trayScale", 0f); }
    public void setTrayScale(float v) { sp.edit().putFloat("trayScale", v).apply(); }

    /** Plus petite taille de case détectée automatiquement (ratio), -1 si inconnue. */
    public float learnedUnit() { return sp.getFloat("learnedUnit", -1f); }
    public void setLearnedUnit(float v) { sp.edit().putFloat("learnedUnit", v).apply(); }

    public int delayMs() { return sp.getInt("delay", 650); }
    public void setDelayMs(int v) { sp.edit().putInt("delay", v).apply(); }

    public int dragMs() { return sp.getInt("drag", 350); }
    public void setDragMs(int v) { sp.edit().putInt("drag", v).apply(); }

    public float minV() { return sp.getFloat("minV", 0.45f); }
    public void setMinV(float v) { sp.edit().putFloat("minV", v).apply(); }

    public void resetLearning() {
        sp.edit().remove("dx").remove("dy").remove("calibrated").remove("learnedUnit").apply();
    }
}
