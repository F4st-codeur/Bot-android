package com.colin.blitzbot;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/** Lit la grille et les pièces à partir d'une capture d'écran. */
public final class ScreenReader {

    /** Une case est "un bloc" si elle est assez lumineuse et colorée (les cases vides sont sombres). */
    public static boolean isBlock(int color, float minV) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        if (max == 0) return false;
        float v = max / 255f;
        float s = (max - min) / (float) max;
        return (v >= minV && s >= 0.25f) || v >= 0.92f;
    }

    public static long readBoard(Bitmap bmp, Rect board, float minV) {
        long result = 0;
        float cw = board.width() / 8f, ch = board.height() / 8f;
        int rad = Math.max(1, (int) (Math.min(cw, ch) * 0.12f));
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                int cx = (int) (board.left + (c + 0.5f) * cw);
                int cy = (int) (board.top + (r + 0.5f) * ch);
                int hit = 0, tot = 0;
                for (int dy = -2; dy <= 2; dy++)
                    for (int dx = -2; dx <= 2; dx++) {
                        int x = clamp(cx + dx * rad, 0, bmp.getWidth() - 1);
                        int y = clamp(cy + dy * rad, 0, bmp.getHeight() - 1);
                        tot++;
                        if (isBlock(bmp.getPixel(x, y), minV)) hit++;
                    }
                if (hit * 2 > tot) result |= 1L << (r * 8 + c);
            }
        return result;
    }

    /** Une pièce détectée dans la zone d'attente. */
    public static final class TrayPiece {
        public final int slot;
        public final RectF box;          // boîte englobante à l'écran
        public Solver.Piece piece;       // forme (après estimation de la taille de case)

        TrayPiece(int slot, RectF box) {
            this.slot = slot;
            this.box = box;
        }
    }

    /** Trouve les boîtes englobantes des pièces dans les 3 emplacements. */
    public static List<TrayPiece> findTrayBoxes(Bitmap bmp, Rect tray, float minV) {
        List<TrayPiece> out = new ArrayList<>();
        Rect t = new Rect(tray);
        if (!t.intersect(0, 0, bmp.getWidth(), bmp.getHeight())) return out;
        int w = t.width(), h = t.height();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, t.left, t.top, w, h);
        int step = 2;
        for (int s = 0; s < 3; s++) {
            int x0 = s * w / 3, x1 = (s + 1) * w / 3;
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = -1, maxY = -1, hits = 0;
            for (int y = 0; y < h; y += step)
                for (int x = x0; x < x1; x += step) {
                    if (isBlock(px[y * w + x], minV)) {
                        hits++;
                        if (x < minX) minX = x;
                        if (x > maxX) maxX = x;
                        if (y < minY) minY = y;
                        if (y > maxY) maxY = y;
                    }
                }
            if (hits < 12) continue;
            out.add(new TrayPiece(s, new RectF(t.left + minX, t.top + minY,
                    t.left + maxX + step, t.top + maxY + step)));
        }
        return out;
    }

    /**
     * Estime la taille d'une case dans la zone d'attente : la plus grande taille
     * pour laquelle toutes les boîtes font un nombre entier (1..5) de cases.
     */
    public static float estimateUnit(List<TrayPiece> boxes, float cell) {
        if (boxes.isEmpty()) return -1;
        for (float k = 1.05f; k >= 0.25f; k -= 0.005f) {
            float u = cell * k;
            boolean ok = true;
            for (TrayPiece tp : boxes) {
                float fw = tp.box.width() / u, fh = tp.box.height() / u;
                int rw = Math.round(fw), rh = Math.round(fh);
                if (rw < 1 || rw > 5 || rh < 1 || rh > 5
                        || Math.abs(fw - rw) > 0.17f || Math.abs(fh - rh) > 0.17f) {
                    ok = false;
                    break;
                }
            }
            if (ok) return u;
        }
        return -1;
    }

    /** Remplit tp.piece en découpant chaque boîte en cases de taille "unit". */
    public static void readShapes(Bitmap bmp, List<TrayPiece> boxes, float unit, float minV) {
        for (TrayPiece tp : boxes) {
            int cols = clamp(Math.round(tp.box.width() / unit), 1, 5);
            int rows = clamp(Math.round(tp.box.height() / unit), 1, 5);
            float cw = tp.box.width() / cols, ch = tp.box.height() / rows;
            boolean[][] g = new boolean[rows][cols];
            boolean any = false;
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++) {
                    int cx = (int) (tp.box.left + (c + 0.5f) * cw);
                    int cy = (int) (tp.box.top + (r + 0.5f) * ch);
                    int hit = 0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int x = clamp(cx + (int) (dx * cw * 0.2f), 0, bmp.getWidth() - 1);
                            int y = clamp(cy + (int) (dy * ch * 0.2f), 0, bmp.getHeight() - 1);
                            if (isBlock(bmp.getPixel(x, y), minV)) hit++;
                        }
                    g[r][c] = hit >= 5;
                    any |= g[r][c];
                }
            tp.piece = any ? new Solver.Piece(g) : null;
        }
    }

    static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
