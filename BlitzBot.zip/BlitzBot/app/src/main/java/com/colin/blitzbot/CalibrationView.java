package com.colin.blitzbot;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

/**
 * Écran de cadrage : l'utilisateur trace un rectangle autour de la grille 8x8,
 * puis un rectangle autour de la zone des 3 pièces. Coordonnées = coordonnées écran.
 */
@SuppressLint("ViewConstructor")
public class CalibrationView extends View {

    public interface Listener {
        void onDone(Rect board, Rect tray);
        void onCancel();
    }

    private final Listener listener;
    private final Paint dim = new Paint(), stroke = new Paint(), text = new Paint(), grid = new Paint();
    private final int[] loc = new int[2];
    private int step = 0;
    private float sx, sy, ex, ey;
    private boolean dragging;
    private Rect board;

    public CalibrationView(Context ctx, Listener l) {
        super(ctx);
        listener = l;
        dim.setColor(Color.argb(90, 0, 0, 0));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5);
        stroke.setColor(Color.CYAN);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(2);
        grid.setColor(Color.argb(200, 0, 255, 255));
        text.setColor(Color.WHITE);
        text.setTextSize(44);
        text.setShadowLayer(6, 0, 0, Color.BLACK);
        text.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        getLocationOnScreen(loc);
        canvas.drawRect(0, 0, getWidth(), getHeight(), dim);
        String msg = step == 0
                ? "1/2 : glisse le doigt pour encadrer\nexactement la grille 8x8"
                : "2/2 : encadre la zone des 3 pièces\n(toute la largeur, en bas)";
        float y = getHeight() * 0.08f;
        for (String line : msg.split("\n")) {
            canvas.drawText(line, 40, y, text);
            y += 56;
        }
        canvas.drawText("(simple appui = annuler)", 40, y, text);

        if (board != null) drawGrid(canvas, board);
        if (dragging) {
            Rect r = current();
            if (step == 0) drawGrid(canvas, r);
            else canvas.drawRect(r.left - loc[0], r.top - loc[1], r.right - loc[0], r.bottom - loc[1], stroke);
        }
    }

    private void drawGrid(Canvas c, Rect r) {
        float l = r.left - loc[0], t = r.top - loc[1];
        float cw = r.width() / 8f, ch = r.height() / 8f;
        for (int i = 0; i <= 8; i++) {
            c.drawLine(l + i * cw, t, l + i * cw, t + r.height(), grid);
            c.drawLine(l, t + i * ch, l + r.width(), t + i * ch, grid);
        }
    }

    private Rect current() {
        return new Rect((int) Math.min(sx, ex), (int) Math.min(sy, ey),
                (int) Math.max(sx, ex), (int) Math.max(sy, ey));
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                sx = ex = e.getRawX();
                sy = ey = e.getRawY();
                dragging = true;
                break;
            case MotionEvent.ACTION_MOVE:
                ex = e.getRawX();
                ey = e.getRawY();
                break;
            case MotionEvent.ACTION_UP:
                dragging = false;
                Rect r = current();
                if (r.width() < 40 || r.height() < 40) {
                    listener.onCancel();
                    return true;
                }
                if (step == 0) {
                    board = r;
                    step = 1;
                } else {
                    listener.onDone(board, r);
                    return true;
                }
                break;
        }
        invalidate();
        return true;
    }
}
