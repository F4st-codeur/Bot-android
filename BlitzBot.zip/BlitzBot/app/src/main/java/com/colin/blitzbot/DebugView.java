package com.colin.blitzbot;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Calque non tactile qui montre ce que le bot "voit". Masqué pendant les captures. */
@SuppressLint("ViewConstructor")
public class DebugView extends View {

    private final Paint outline = new Paint(), dot = new Paint(), box = new Paint(), plan = new Paint();
    private final int[] loc = new int[2];

    private Rect board, tray;
    private long cells;
    private final List<RectF> boxes = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private long planMask;

    public DebugView(Context ctx) {
        super(ctx);
        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeWidth(3);
        outline.setColor(Color.WHITE);
        dot.setColor(Color.GREEN);
        box.setStyle(Paint.Style.STROKE);
        box.setStrokeWidth(4);
        box.setColor(Color.YELLOW);
        box.setTextSize(36);
        plan.setStyle(Paint.Style.STROKE);
        plan.setStrokeWidth(6);
        plan.setColor(Color.MAGENTA);
    }

    public void update(Rect board, Rect tray, long cells, List<ScreenReader.TrayPiece> pieces, long planMask) {
        this.board = board;
        this.tray = tray;
        this.cells = cells;
        this.planMask = planMask;
        boxes.clear();
        labels.clear();
        if (pieces != null)
            for (ScreenReader.TrayPiece tp : pieces) {
                boxes.add(new RectF(tp.box));
                labels.add(tp.piece == null ? "?" : tp.piece.rows + "x" + tp.piece.cols);
            }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (board == null) return;
        getLocationOnScreen(loc);
        float ox = -loc[0], oy = -loc[1];
        c.drawRect(board.left + ox, board.top + oy, board.right + ox, board.bottom + oy, outline);
        if (tray != null) c.drawRect(tray.left + ox, tray.top + oy, tray.right + ox, tray.bottom + oy, outline);
        float cw = board.width() / 8f, ch = board.height() / 8f;
        for (int r = 0; r < 8; r++)
            for (int col = 0; col < 8; col++) {
                long b = 1L << (r * 8 + col);
                float x = board.left + ox + (col + 0.5f) * cw, y = board.top + oy + (r + 0.5f) * ch;
                if ((cells & b) != 0) c.drawCircle(x, y, cw * 0.12f, dot);
                if ((planMask & b) != 0)
                    c.drawRect(x - cw * 0.4f, y - ch * 0.4f, x + cw * 0.4f, y + ch * 0.4f, plan);
            }
        for (int i = 0; i < boxes.size(); i++) {
            RectF r = boxes.get(i);
            c.drawRect(r.left + ox, r.top + oy, r.right + ox, r.bottom + oy, box);
            c.drawText(labels.get(i), r.left + ox, r.top + oy - 8, box);
        }
    }
}
